#ifndef TYPES_H
#define TYPES_H

#include <stdbool.h>



char Stack[100];
int TOS;

#endif